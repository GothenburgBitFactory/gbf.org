/* cmake.h.in. Creates cmake.h during a build */

/* Package information */
#define PACKAGE "vramsteg"
#define VERSION "1.1.0"
#define PACKAGE_BUGREPORT "support@yootabory.com"
#define PACKAGE_NAME      "vramsteg"
#define PACKAGE_TARNAME   "vramsteg"
#define PACKAGE_VERSION   "1.1.0"
#define PACKAGE_STRING    "vramsteg 1.1.0"

/* git information */
#define HAVE_COMMIT

/* Compiling platform */
/* #undef LINUX */
#define DARWIN
/* #undef CYGWIN */
/* #undef FREEBSD */
/* #undef OPENBSD */
/* #undef NETBSD */
/* #undef HAIKU */
/* #undef SOLARIS */
/* #undef KFREEBSD */
/* #undef GNUHURD */
/* #undef UNKNOWN */
