/* cmake.h.in. Creates cmake.h during a build */

/* Package information */
#define PACKAGE "anomaly"
#define VERSION "1.1.0"
#define PACKAGE_BUGREPORT "support@taskwarrior.org"
#define PACKAGE_NAME      "anomaly"
#define PACKAGE_TARNAME   "anomaly"
#define PACKAGE_VERSION   "1.1.0"
#define PACKAGE_STRING    "anomaly 1.1.0"

/* git information */
#define HAVE_COMMIT

/* Compiling platform */
/* #undef LINUX */
#define DARWIN
/* #undef KFREEBSD */
/* #undef FREEBSD */
/* #undef OPENBSD */
/* #undef NETBSD */
/* #undef SOLARIS */
/* #undef GNUHURD */
/* #undef CYGWIN */
/* #undef UNKNOWN */

/* Found tm.tm_gmtoff struct member */
/* #undef HAVE_TM_GMTOFF */

/* Found st.st_birthtime struct member */
/* #undef HAVE_ST_BIRTHTIME */

/* Functions */
/* #undef HAVE_GET_CURRENT_DIR_NAME */
/* #undef HAVE_TIMEGM */
/* #undef HAVE_UUID_UNPARSE_LOWER */

