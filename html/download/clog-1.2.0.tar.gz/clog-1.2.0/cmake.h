/* cmake.h.in. Creates cmake.h during a build */

/* Package information */
#define PACKAGE "clog"
#define VERSION "1.2.0"
#define PACKAGE_BUGREPORT "support@yootabory.com"
#define PACKAGE_NAME      "clog"
#define PACKAGE_TARNAME   "clog"
#define PACKAGE_VERSION   "1.2.0"
#define PACKAGE_STRING    "clog 1.2.0"

/* git information */
#define HAVE_COMMIT

/* Compiling platform */
/* #undef LINUX */
#define DARWIN
/* #undef CYGWIN */
/* #undef FREEBSD */
/* #undef OPENBSD */
/* #undef HAIKU */
/* #undef SOLARIS */
/* #undef UNKNOWN */

